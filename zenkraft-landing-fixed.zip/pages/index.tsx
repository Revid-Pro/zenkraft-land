import Head from 'next/head';

export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-white">
      <Head>
        <title>Zenkraft - Freelance AI Platform</title>
      </Head>
      <main className="text-center p-6">
        <h1 className="text-4xl md:text-6xl font-bold text-gray-900">Zenkraft</h1>
        <p className="mt-4 text-xl text-gray-600">Üret. Büyü. Parılda.</p>
        <button className="mt-6 px-6 py-3 bg-blue-600 text-white rounded-xl shadow-lg hover:bg-blue-700 transition">
          Ön Kayıt Ol
        </button>
      </main>
    </div>
  );
}
